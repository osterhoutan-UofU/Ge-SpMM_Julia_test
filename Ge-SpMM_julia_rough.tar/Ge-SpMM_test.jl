using Random
using Test
include("Ge-SpMM.jl") # include the julia code for the Ge-SpMM algorithms.
 
TEST_FP_TOLLERANCE  = 0.0001

TEST_DIMS   = [ (M=  64, K=  64, N=  64, SR= 0.01 ), # already now this works
                (M=  32, K=  64, N=  64, SR= 0.01 ), # test if 32 makes bad bounds per dimension
                (M=  64, K=  32, N=  64, SR= 0.01 ), # ...
                (M=  64, K=  64, N=  32, SR= 0.01 ), # ...
                (M=  64, K=  32, N=  32, SR= 0.01 ), # more rigerouse 32 bound tests 
                (M=  32, K=  32, N=  64, SR= 0.01 ), # ...
                (M=  64, K=  32, N=  64, SR= 0.01 ), # ...
                (M= 128, K=  64, N=  64, SR= 0.01 ), # Start testing larger dimensions
                (M=  64, K= 128, N=  64, SR= 0.01 ), # ...
                (M=  64, K=  64, N= 128, SR= 0.01 ), # ...
                (M=  32, K= 128, N=  64, SR= 0.01 ), # Rand known dimens test
                (M=  64, K= 128, N=  32, SR= 0.01 ), # ...
                (M= 128, K=  30, N= 128, SR= 0.01 ), # Test if haivng dim < warp_size causes issues
                (M= 128, K= 128, N=  30, SR= 0.01 ), # ...
                (M=  30, K= 128, N= 128, SR= 0.01 ), # ...
                (M=  49, K= 112, N=  92, SR= 0.01 ), # Test if odd numbered dim causes issues (+ non base 2 numbers)
                (M=  92, K=  49, N= 112, SR= 0.01 ), # ...
                (M= 112, K=  92, N=  49, SR= 0.01 ), # ...
                (M= 256, K= 256, N= 256, SR= 0.01 ), # Test increasignly larger sizes
                (M= 512, K= 512, N= 512, SR= 0.008), # ...
                (M=1024, K=1024, N=1024, SR= 0.005), # ...
                (M=2048, K=1024, N=2048, SR= 0.005), # ...
                (M=2048, K=2048, N=2048, SR= 0.002), # ...
                (M=4096, K=1024, N=4096, SR= 0.002), # ...
                (M=4096, K=4096, N=4096, SR= 0.001)] # ...

RAND_TEST_COUNT = 5 




# << ======================================================================= >> 
# <<                                TEST SETS                                >> 
# << ======================================================================= >> 


# << ============================== SpMM_lin =============================== >> 

@testset verbose=true "`SpMM_lin` :: KNOWN Sizes w/ KNOWN data" begin
    @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR)" for dims in TEST_DIMS
        @test (_Test__SpMM_lin(dims, false))
    end #? @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR)" for dims in TEST_DIMS
end #? @testset "`SpMM_lin` :: KNOWN Sizes w/ KNOWN data"

@testset verbose=true "`SpMM_lin` :: KNOWN Sizes w/ RANDOM data" begin
    doRand=true
    for i in 1:RAND_TEST_COUNT
        @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR) x$i" for dims in TEST_DIMS
            @test (_Test__SpMM_lin(dims, true))
        end #? @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR) x$i" for dims in TEST_DIMS
    end
end #? @testset "`SpMM_lin` :: KNOWN Sizes w/ RANDOM data"


# << ================================ SpMM ================================= >> 

@testset verbose=true "`SpMM` :: KNOWN Sizes w/ KNOWN data" begin
    @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR)" for dims in TEST_DIMS
        @test (_Test__SpMM(dims, false))
    end #? @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR)" for dims in TEST_DIMS
end #? @testset "`SpMM_lin` :: KNOWN Sizes w/ KNOWN data"

@testset verbose=true "`SpMM` :: KNOWN Sizes w/ RANDOM data" begin
    for i in 1:RAND_TEST_COUNT
        @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR) x$i" for dims in TEST_DIMS
            @test (_Test__SpMM(dims, true))
        end #? @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR) x$i" for dims in TEST_DIMS
    end
end #? @testset "`SpMM_lin` :: KNOWN Sizes w/ RANDOM data"


# << ============================== SpMM2_lin ============================== >> 

@testset verbose=true "`SpMM2_lin` :: KNOWN Sizes w/ KNOWN data" begin
    @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR)" for dims in TEST_DIMS
        @test (_Test__SpMM2_lin(dims, false))
    end #? @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR)" for dims in TEST_DIMS
end #? @testset "`SpMM_lin` :: KNOWN Sizes w/ KNOWN data"

@testset verbose=true "`SpMM2_lin` :: KNOWN Sizes w/ RANDOM data" begin
    for i in 1:RAND_TEST_COUNT
        @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR) x$i" for dims in TEST_DIMS
            @test (_Test__SpMM2_lin(dims, true))
        end #? @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR) x$i" for dims in TEST_DIMS
    end
end #? @testset "`SpMM_lin` :: KNOWN Sizes w/ KNOWN data"


# << ================================ SpMM2 ================================ >> 

@testset verbose=true "`SpMM2` :: KNOWN Sizes w/ KNOWN data" begin
    @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR)" for dims in TEST_DIMS
        @test (_Test__SpMM2(dims, false))
    end #? @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR)" for dims in TEST_DIMS
end #? @testset "`SpMM_lin` :: KNOWN Sizes w/ KNOWN data"

@testset verbose=true "`SpMM2` :: KNOWN Sizes w/ RANDOM data" begin
    for i in 1:RAND_TEST_COUNT
        @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR) x$i" for dims in TEST_DIMS
            @test (_Test__SpMM2(dims, true))
        end #? @testset "Dims: (M:$(dims.M), K:$(dims.K), N:$(dims.N)) SR: $(dims.SR) x$i" for dims in TEST_DIMS
    end
end #? @testset "`SpMM_lin` :: KNOWN Sizes w/ RANDOM data"

